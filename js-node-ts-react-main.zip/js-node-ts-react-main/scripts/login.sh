#!/bin/bash

http POST http://localhost:6600/login username=jartsa password=joo Content-Type:application/json
